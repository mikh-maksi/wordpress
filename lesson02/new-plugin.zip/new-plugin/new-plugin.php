<?php
/**
 * Plugin Name: Новий плагін
 * Description: Опис плагіну (140 символів)
*/

